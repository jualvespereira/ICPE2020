#!/bin/bash

numb='20'
logfilename="/srv/local/macher/bench4/output/$numb.log"
trailerlocation='/srv/local/macher/bench4/crowd_run_1080p50.y4m'

TIMEFORMAT="USERTIME %U                                                                                            
SYSTEMTIME %S                                                                                                      
ELAPSEDTIME %R"; { time ../x264/x264 --no-asm --ref 9 --no-deblock --no-mbtree --rc-lookahead 40  --no-cabac --no-weightb  -o /srv/local/macher/bench4/tempvids/sintel$numb.flv $trailerlocation ; } 2> $logfilename
# size of the video
size=`ls -lrt /srv/local/macher/bench4/tempvids/sintel$numb.flv | awk '{print $5}'`
# analyze log to extract relevant timing information
usertime=`grep "USERTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
systemtime=`grep "SYSTEMTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
elapsedtime=`grep "ELAPSEDTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
# clean
rm /srv/local/macher/bench4/tempvids/sintel$numb.flv


csvLine='20,true,false,true,true,true,false,true,false,true,40,9'
csvLine="$csvLine,$size,$usertime,$systemtime,$elapsedtime"
echo $csvLine
#!/bin/bash

numb='153'
logfilename="/srv/local/macher/bench6/output/$numb.log"
trailerlocation='/srv/local/macher/bench6/eledream_640x360_128.y4m'

TIMEFORMAT="USERTIME %U                                                                                            
SYSTEMTIME %S                                                                                                      
ELAPSEDTIME %R"; { time ../x264/x264 --no-asm --ref 1 --no-fast-pskip --rc-lookahead 60 --no-deblock  --no-cabac --no-mixed-refs  -o /srv/local/macher/bench6/tempvids/sintel$numb.flv $trailerlocation ; } 2> $logfilename
# size of the video
size=`ls -lrt /srv/local/macher/bench6/tempvids/sintel$numb.flv | awk '{print $5}'`
# analyze log to extract relevant timing information
usertime=`grep "USERTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
systemtime=`grep "SYSTEMTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
elapsedtime=`grep "ELAPSEDTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
# clean
rm /srv/local/macher/bench6/tempvids/sintel$numb.flv


csvLine='153,true,false,true,true,true,true,false,true,false,60,1'
csvLine="$csvLine,$size,$usertime,$systemtime,$elapsedtime"
echo $csvLine
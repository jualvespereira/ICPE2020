#!/bin/bash

numb='397'
logfilename="$numb.log"
trailerlocation='../akiyo_qcif.y4m'
TIMEFORMAT="USERTIME %U                                                                                            
SYSTEMTIME %S                                                                                                      
ELAPSEDTIME %R"; { time x264 --no-asm --ref 1 --no-fast-pskip --no-mbtree --rc-lookahead 20  --no-cabac --no-mixed-refs  -o sintel$numb.mkv $trailerlocation ; } 2> $logfilename
# size of the video
size=`du -k sintel$numb.mkv | cut -f1`
# clean
rm sintel$numb.mkv

# analyze log to extract relevant timing information
usertime=`grep "USERTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
systemtime=`grep "SYSTEMTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
elapsedtime=`grep "ELAPSEDTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`

csvLine='397,true,false,true,true,false,true,true,true,false,20,1'
csvLine="$csvLine,$size,$usertime,$systemtime,$elapsedtime"
echo $csvLine
#!/bin/bash

numb='295'
logfilename="$numb.log"
trailerlocation='../akiyo_qcif.y4m'
TIMEFORMAT="USERTIME %U                                                                                            
SYSTEMTIME %S                                                                                                      
ELAPSEDTIME %R"; { time x264 --no-asm --ref 5 --no-mbtree --no-deblock --rc-lookahead 20  --no-cabac --no-weightb --no-mixed-refs  -o sintel$numb.flv $trailerlocation ; } 2> $logfilename
# size of the video
size=`du -k sintel$numb.flv | cut -f1`
# clean
rm sintel$numb.flv

# analyze log to extract relevant timing information
usertime=`grep "USERTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
systemtime=`grep "SYSTEMTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`
elapsedtime=`grep "ELAPSEDTIME" $logfilename | sed 's/[^.,0-9]*//g ; s/,/./g'`

csvLine='295,true,false,true,true,true,false,true,true,true,20,5'
csvLine="$csvLine,$size,$usertime,$systemtime,$elapsedtime"
echo $csvLine